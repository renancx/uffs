#Universidade Federal da Fronteira Sul
#Integrantes: Joao Vitor Betiatto & Renan Carlos Loewenstein

from re import findall as find, match, split #biblioteca de expressoes regulares

#=================================================================================
def uniaoEstados(automato, estados):
    #Faz a uniao de todos os estados do automato que estao na lista de estados
    final = {} #simbolos e os estados acessiveis a partir dele, eh atualizado a cada passagem pela funcao 
    def unir(estado):
        for e in estado:
            if e in final:
                final[e] = uniaoListas(final[e], estado[e])
            else:
                final.update({e: estado[e]})

    for estado in estados: #percorre todos os estados que precisam ser unidos, e adiciona as transicoes de cada simbolo no dicionario final
        unir(automato[estado])
    return final

def uniaoListas(l1, l2):
    return l1 + list(set(l2) - set(l1))

def unirAutomatos(afd, afndTemp):
    mapaNovosEstados = {x: x + len(afd) for x in range(len(afndTemp))} #cria um dicionario com as novas posicoes na afnd
    aux = []

    if '&' in afd[0].keys():  #Eh criado uma nova regra S que leva a regra S por epsilon transicao
        afd[0]['&'].append(mapaNovosEstados[0])
    else:
        afd[0].update({'&': [mapaNovosEstados[0]]})
    
    for chave in afndTemp.keys(): #percorre os estados do afnd temporario
        for ch in afndTemp[chave].keys():
            if ch == '*': 
                continue
            aux = []
            for i in afndTemp[chave][ch]: #percorre os estados atingiveis pelo simbolo
                aux.append(mapaNovosEstados[i]) 
            afndTemp[chave][ch] = aux #atualiza os estados atingiveis da afnd temporaria

    for chave in afndTemp.keys():
        afd.update({mapaNovosEstados[chave] : afndTemp[chave]}) #cria os novos estados na afnd principal

def mostrarDeterministico(afnd, alfabeto): #Funcao que imprime o automato deterministico
    alfabeto.sort()
    print('     {}'.format('-----'*len(alfabeto)))
    print('     |', end='')
    for i in alfabeto:
        print('  {:2}|'.format(i), end='')
    print('\n     {}'.format('-----'*len(alfabeto)))
    for i in afnd.keys():
        if '*' in afnd[i].keys():
            print('*', end='')
        else:
            print(' ', end='')
        print('{:3}:|'.format(i), end='')
        for j in alfabeto:
            if j in afnd[i].keys():
                print(' {:2} |'.format(afnd[i][j][0]), end='')
            else:
                print(' {:2} |'.format('-'), end='')
        print('')
    print('     {}'.format('-----'*len(alfabeto)))

#=================================================================================
#Eliminar epsilon transicoes

def eliminaEpsilonT(afnd): # Funcao que elimina as epsilon transicoes
    epsilon = []

    for chave in afnd.keys(): #mapeia os estados que possuem epsilon transicao
        if '&' in afnd[chave]:
            epsilon.append(chave)

    def copiarRegras(regras, nRegra):  #Recursivamente copia regras que sao acessadas por uma epsilon transicao
        if nRegra not in epsilon:
            return  #Caso nao tenha epsilon transicoes na regra
        
        epsilon.remove(nRegra) 
        
        for regra in regras['&']: #percorre os estados que sao acessiveis por epsilon transicao
            chaves = afnd[regra].keys() #salva os simbolos dos estados atingidos por epsilon transicao
            
            if '&' in chaves: #caso os estados atingidos tenham epsilon transicao, remove recursivamente
                copiarRegras(afnd[regra], regra)
                regras['&'] = uniaoListas(regras['&'], afnd[regra]['&'])
        
        # une as transicoes de cada simbolo dos estados atingidos por epsilon transicao, com as regras do estado que tem epsilon transicao
        afnd[nRegra] = uniaoEstados(afnd, regras['&'] + [nRegra]) 

    epAux = epsilon.copy()
    
    for ep in epAux:
        copiarRegras(afnd[ep], ep) #copia as regras dos estados atingidos por epsilon transicao, para o estado que tinha epsilon transicao
    
    for ep in epAux:
        del afnd[ep]['&'] #apaga as regras dos estados que tenham epsilon transicao

#=================================================================================
#Determinização
def determinizar(afnd):
    mpRgs = {}
    visitados = set()

    def determiniza(regra, nReg):  #Recursivamente determiniza o automato
        if nReg in visitados: 
            return
        visitados.add(nReg) 
        chaves = list(regra.keys()) 

        for chave in chaves:
            if len(regra[chave]) > 1: #se a regra tiver mais que uma transicao
                regra[chave].sort()
                nRg = str(regra[chave])  # eh gerada uma nova regra que sera mapeada no mpReg
                
                if nRg not in mpRgs.keys(): 
                    nEst = len(afnd)  # Novo estado que sera mapeado pela variavel nRg
                    mpRgs.update({nRg: nEst})
                    afnd.update({len(afnd): uniaoEstados(afnd, regra[chave])})
                    determiniza(afnd[nEst], nEst) # determiniza os novos estados criados
                
                regra.update({chave: [mpRgs[nRg]]}) # atualiza a regra que tinha mais que uma transicao, para o novo estado criado

    i, t = 0, len(afnd)
    while i < t:
        determiniza(afnd[i], i)
        i, t = i + 1, len(afnd)  # Cada nova regra criada tambehm deve ser determinizada

#=================================================================================
#Eliminar inalcancaveis
def removeInalcancaveis(afnd): #Funcao para eliminar inalcancaveis
    visitados = set()

    def elimina(regra, estado): #utiliza uma dfs para remover recursivamente
        if estado in visitados:
            return
        
        visitados.add(estado)
        
        for chave in regra.keys():
            if chave == '*':
                continue
            for i in regra[chave]:
                elimina(afnd[i], i)

    elimina(afnd[0], 0)
    x = len(afnd)

    for i in range(x):
        if i not in visitados: #apos a dfs estados nao visitados sao eliminados
            del afnd[i]


def removeInuteis(afnd): #funcao para eliminar inuteis
    visitados = set()
    uteis = set()
    
    for rg in afnd:
        if '*' in afnd[rg].keys():
            uteis.add(rg)
    
    def elimina(regra, nRegra): #utiliza uma dfs para encontrar os estados inuteis
        if nRegra in uteis:
            return True
        
        visitados.add(nRegra)
        
        for chave in regra.keys():
            for rg in regra[chave]:
                if rg not in visitados:
                    if elimina(afnd[rg], rg):
                        return True
        return False

    aux = list(afnd.keys())
    
    for regra in aux:
        if elimina(afnd[regra], regra):
            uteis.add(regra)
        visitados = set()
    
    for regra in aux:
        if regra not in uteis: #apos a dfs estados que nao estao em uteis sao eliminados
            del afnd[regra]
    
    for regra in afnd.keys(): #transicoes para estados nao uteis tambem sao eliminados
        aux = list(afnd[regra].keys())
        for chave in aux:
            if chave == '*':
                continue
            
            for rg in afnd[regra][chave]:
                if rg not in uteis:
                    del afnd[regra][chave]

#=================================================================================
def gerarTokenAFND(afnd, token, alfabeto): #Funcao que gera afnd token
    if not afnd:
        afnd.update({len(afnd): {}}) #o afnd eh gerado com index de (tamanho atual da afnd = 0, 1, 2, 3 -- Criando assim as regras)
    
    tokenInicial = True #primeiro caracter inicial, o que vai guiar para as proximas regras
    
    for tk in token:
        if tk not in alfabeto: #se o caracter ainda nao estiver no alfabeto aceito
            alfabeto.append(tk) #adiciona no alfabeto da linguagem
        
        if tokenInicial: #token inicial vai para o primeiro estado do automato
            mapeado = afnd[0] #ponteiro para o estado inicial

            if tk in mapeado.keys():
                mapeado[tk].append(len(afnd)) #caso ja exista uma regra com esse simbolo, adiciona uma transicao para um novo estado para essa regra
            else:
                mapeado.update({tk : [len(afnd)]})
            tokenInicial = False
        else:
            afnd.update({len(afnd) : {tk: [len(afnd) + 1]}}) #cria um novo estado, que ira levar para o proximo a partir do simbolo
    
    afnd.update({len(afnd) : {'*': [1]}}) #quando chega ao final do token, o novo estado criado eh final

def gerarGramaticaAFND(afnd, gramatica, alfabeto):  #Funcao que gera a gramatica afnd
    if not afnd: #cria o afnd se nao tiver palavras reservada
        afnd.update({0: {}})
    
    afndTemporario = {}
    mapaRegras = {}
    
    for regra in gramatica: #percorre as producoes da gramatica
        simbolos = find(r'(\w*<\w+>|\w+|&)', regra) #quebra em regra e suas producoes
        
        if simbolos[0] in mapaRegras.keys(): #verifica se a regra ja foi criada
            indiceRegra = mapaRegras[simbolos[0]] 
        else:
            indiceRegra = len(afndTemporario) #indice da regra
            afndTemporario.update({indiceRegra : {}}) #cria um novo estado do automato temporario
            mapaRegras.update({simbolos[0]: indiceRegra}) #mapeia a regra fazendo relacionacao com o indice do novo estado criado no automato

        for simbolo in simbolos[1:]: #percorre as producoes da regra
            terminal = find(r'^\w+', simbolo) 
            naoTerminal = find(r'<\w+>', simbolo) 
            terminal = '&' if not terminal else terminal[0] #caso nao achar um simbolo terminal cria um epsilon transicao

            if terminal not in alfabeto:
                alfabeto.append(terminal)

            if not naoTerminal: #producao sem nao terminal (gera uma regra que tem transicao para um estado terminal)
                rg = afndTemporario[indiceRegra]

                if terminal in rg.keys():
                    rg[terminal].append(len(afndTemporario)) #acrescenta nova transicao no simbolo
                else:
                    rg.update({terminal : [len(afndTemporario)]}) #cria um novo simbolo no estado

                afndTemporario.update({len(afndTemporario): {'*':[1]}}) #cria um novo estado/regra terminal
            else:
                naoTerminal = naoTerminal[0]

                if naoTerminal in mapaRegras.keys():
                    rg = mapaRegras[naoTerminal] #armazena o indice do estado do automato correspondente a regra lida
                else:
                    rg = len(afndTemporario) #indice do novo estado
                    mapaRegras.update({naoTerminal: rg}) #mapeia a regra fazendo relacao com o indice do novo estado criado no automato
                    afndTemporario.update({rg: {}})
                
                mp = afndTemporario[indiceRegra] #ponteiro para o estado do automato corresponde a regra sendo lida
                
                if terminal in mp.keys():
                    mp[terminal].append(rg) #cria a transicao para o estado do referente ao nao terminal
                else:
                    mp.update({terminal: [rg]}) #acrescenta mais uma transicao para o simbolo ja existente

    unirAutomatos(afnd, afndTemporario)

#=================================================================================
afd = {}
alfabeto = []
gramatica = []

entrada = open("entrada.txt", "r")
entradaString = entrada.read() #salva conteudo do arquivo de entrada em uma string 
entradaLista = entradaString.split('\n') #quebra a string em uma lista (quebra de linha eh o separador)

listaAuxiliar = entradaLista.copy()

for tokenLido in listaAuxiliar:
    if not tokenLido:
        entradaLista.remove(tokenLido)
        break 
    gerarTokenAFND(afd, tokenLido, alfabeto) #adiciona ao afnd as regras de producao para o token lido
    entradaLista.remove(tokenLido)

listaAuxiliar = entradaLista.copy() #agora na lista de entrada, temos apenas as gramaticas para serem lidas

while entradaLista:
    for regraGramaticaLida in listaAuxiliar:    
        if not regraGramaticaLida:
            gerarGramaticaAFND(afd, gramatica, alfabeto) 
            gramatica.clear() 
            entradaLista.remove(regraGramaticaLida)
        else:
            gramatica.append(regraGramaticaLida) 
            entradaLista.remove(regraGramaticaLida)

eliminaEpsilonT(afd)
determinizar(afd)
print('Automato finito deterministico(AFD):')
mostrarDeterministico(afd, alfabeto)
removeInalcancaveis(afd)
print('\n Depois de eliminar elementos inalcancaveis:')
mostrarDeterministico(afd, alfabeto)
removeInuteis(afd)
print('\n Depois de eliminar elementos inuteis:')
mostrarDeterministico(afd, alfabeto)