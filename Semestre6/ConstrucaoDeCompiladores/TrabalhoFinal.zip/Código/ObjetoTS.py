class ObjectoTS:
    def __init__(self, linha, rotulo, tipo, estado, tipoVar, id):
        self.linha = linha
        self.rotulo = rotulo
        self.tipo = tipo
        self.estado = estado
        self.tipoVar = tipoVar
        self.id = id